# Some useful global variables

# If the bird is not colliding anything
bird_collision = False

# If the hit sound is played or not
hit_played = False

highest_score = 0
update_score = False

user_started = False
score = 0
